"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SavedEncounter = void 0;
var Toolbox_1 = require("./Toolbox");
var SavedEncounter;
(function (SavedEncounter) {
    function GetSearchHint(encounterState) {
        return encounterState.Combatants.map(function (c) { return c.Alias; }).join(" ");
    }
    SavedEncounter.GetSearchHint = GetSearchHint;
    function Default() {
        return {
            Combatants: [],
            Id: (0, Toolbox_1.probablyUniqueString)(),
            Name: "",
            Path: "",
            Version: process.env.VERSION || "0.0.0"
        };
    }
    SavedEncounter.Default = Default;
})(SavedEncounter || (exports.SavedEncounter = SavedEncounter = {}));
//# sourceMappingURL=SavedEncounter.js.map