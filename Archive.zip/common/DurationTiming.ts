export type DurationTiming = "StartOfTurn" | "EndOfTurn";
