"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CommandSetting = void 0;
var CommandSetting = (function () {
    function CommandSetting() {
    }
    return CommandSetting;
}());
exports.CommandSetting = CommandSetting;
//# sourceMappingURL=CommandSetting.js.map