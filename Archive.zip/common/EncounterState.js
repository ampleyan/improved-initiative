"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EncounterState = void 0;
var EncounterState;
(function (EncounterState) {
    function Default() {
        return {
            ActiveCombatantId: null,
            RoundCounter: 0,
            ElapsedSeconds: 0,
            Combatants: []
        };
    }
    EncounterState.Default = Default;
})(EncounterState || (exports.EncounterState = EncounterState = {}));
//# sourceMappingURL=EncounterState.js.map