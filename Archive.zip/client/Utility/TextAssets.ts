export const TextAssets = {
  BonusActions: "Bonus Actions",
  LegendaryActions: "Legendary Actions",
  MythicActions: "Mythic Actions",
  DamageVulnerabilities: "Damage Vulnerabilities",
  DamageResistances: "Damage Resistances",
  DamageImmunities: "Damage Immunities",
  ConditionImmunities: "Condition Immunities"
};
