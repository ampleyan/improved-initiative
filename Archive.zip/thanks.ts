// Contributors to Improved Initiative are invited to add their names and
// Patreon Ids to this document to get complimentary Epic Initiative.
// See CONTRIBUTING.md for more details.
export default [
  {
    Name: "Evan Bailey",
    Github: "https://github.com/cynicaloptimist/",
    PatreonId: "4767544"
  },
  {
    Name: "Will Eddins",
    Github: "https://github.com/ascendedguard",
    PatreonId: "11511940"
  },
  {
    Name: "Kevin Groke",
    Github: "https://github.com/groke",
    PatreonId: "9115589"
  },
  {
    Name: "Mark Old",
    Github: "https://github.com/dlom",
    PatreonId: "11639636"
  },
  {
    Name: "Dan Lichty",
    Github: "https://github.com/danlite",
    PatreonId: "88868"
  },
  {
    Name: "Corey Kelly",
    Github: "https://github.com/coreyjkelly",
    PatreonId: "32605"
  },
  {
    Name: "Keith Yates",
    Github: "https://github.com/TheKrush",
    PatreonId: "12370603"
  },
  {
    Name: "Sarah Sunday",
    Github: "https://github.com/ssunday",
    PatreonId: "26960184"
  },
  {
    Name: "Daniel Tonon",
    Github: "https://github.com/Dan503",
    PatreonId: "3892078"
  },
  {
    Name: "Nate Whittington",
    Github: "https://github.com/bluecliffadventures",
    PatreonId: "4000000"
  }
];
