"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.saveEntitySet = exports.saveEntity = exports.deleteEntity = exports.getEntity = exports.setSettings = exports.deleteAccount = exports.getFullAccount = exports.getAccount = exports.upsertUser = exports.close = exports.initialize = void 0;
var mongo = require("mongodb");
var _ = require("lodash");
var PersistentCharacter_1 = require("../common/PersistentCharacter");
var SavedEncounter_1 = require("../common/SavedEncounter");
var Spell_1 = require("../common/Spell");
var StatBlock_1 = require("../common/StatBlock");
var mongoClient;
var initialize = function (connectionString) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (!connectionString) {
                    console.log("No connection string found.");
                    return [2];
                }
                mongoClient = new mongo.MongoClient(connectionString);
                return [4, mongoClient.connect()];
            case 1:
                _a.sent();
                return [2];
        }
    });
}); };
exports.initialize = initialize;
var close = function () { return __awaiter(void 0, void 0, void 0, function () { return __generator(this, function (_a) {
    switch (_a.label) {
        case 0: return [4, mongoClient.close()];
        case 1: return [2, _a.sent()];
    }
}); }); };
exports.close = close;
function upsertUser(patreonId, accountStatus, emailAddress) {
    return __awaiter(this, void 0, void 0, function () {
        var db, users, result, user;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!mongoClient) {
                        console.error("No mongo client initialized");
                        throw "No mongo client initialized";
                    }
                    db = mongoClient.db();
                    return [4, db.collection("users")];
                case 1:
                    users = _a.sent();
                    return [4, users.findOneAndUpdate({
                            patreonId: patreonId
                        }, {
                            $set: {
                                patreonId: patreonId,
                                accountStatus: accountStatus,
                                emailAddress: emailAddress
                            },
                            $setOnInsert: {
                                statblocks: {},
                                persistentcharacters: {},
                                spells: {},
                                encounters: {},
                                settings: {}
                            }
                        }, {
                            upsert: true,
                            returnDocument: "after"
                        })];
                case 2:
                    result = _a.sent();
                    user = result.value;
                    return [2, user];
            }
        });
    });
}
exports.upsertUser = upsertUser;
function getAccount(userId) {
    return __awaiter(this, void 0, void 0, function () {
        var user, userWithListings;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4, getFullAccount(userId)];
                case 1:
                    user = _a.sent();
                    if (!user) {
                        return [2, null];
                    }
                    userWithListings = {
                        accountStatus: user.accountStatus,
                        settings: user.settings,
                        statblocks: getStatBlockListings(user.statblocks),
                        persistentcharacters: getPersistentCharacterListings(user.persistentcharacters),
                        spells: getSpellListings(user.spells),
                        encounters: getEncounterListings(user.encounters)
                    };
                    return [2, userWithListings];
            }
        });
    });
}
exports.getAccount = getAccount;
function getFullAccount(userId) {
    return __awaiter(this, void 0, void 0, function () {
        var db, users, user, userAccount;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!mongoClient) {
                        throw "No mongo client initialized";
                    }
                    db = mongoClient.db();
                    users = db.collection("users");
                    if (typeof userId === "string") {
                        userId = new mongo.ObjectId(userId);
                    }
                    return [4, users.findOne({ _id: userId })];
                case 1:
                    user = _a.sent();
                    if (user === null) {
                        return [2, null];
                    }
                    return [4, updatePersistentCharactersIfNeeded(user, users)];
                case 2:
                    _a.sent();
                    userAccount = {
                        accountStatus: user.accountStatus,
                        settings: user.settings,
                        statblocks: user.statblocks,
                        persistentcharacters: user.persistentcharacters || {},
                        spells: user.spells,
                        encounters: user.encounters
                    };
                    return [2, userAccount];
            }
        });
    });
}
exports.getFullAccount = getFullAccount;
function deleteAccount(userId) {
    return __awaiter(this, void 0, void 0, function () {
        var db, users, result;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!mongoClient) {
                        throw "No mongo client initialized";
                    }
                    db = mongoClient.db();
                    users = db.collection("users");
                    if (typeof userId === "string") {
                        userId = new mongo.ObjectId(userId);
                    }
                    return [4, users.deleteOne({ _id: userId })];
                case 1:
                    result = _a.sent();
                    return [2, result.deletedCount];
            }
        });
    });
}
exports.deleteAccount = deleteAccount;
function updatePersistentCharactersIfNeeded(user, users) {
    return __awaiter(this, void 0, void 0, function () {
        var persistentcharacters;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (user.persistentcharacters != undefined &&
                        !_.isEmpty(user.persistentcharacters)) {
                        return [2, false];
                    }
                    if (!user.playercharacters) {
                        return [2, false];
                    }
                    persistentcharacters = _.mapValues(user.playercharacters, function (statBlockUnsafe) {
                        var statBlock = __assign(__assign({}, StatBlock_1.StatBlock.Default()), statBlockUnsafe);
                        return PersistentCharacter_1.PersistentCharacter.Initialize(statBlock);
                    });
                    return [4, users.updateOne({ _id: user._id }, { $set: { persistentcharacters: persistentcharacters } })];
                case 1:
                    _a.sent();
                    user.persistentcharacters = persistentcharacters;
                    return [2, true];
            }
        });
    });
}
function getStatBlockListings(statBlocks) {
    return Object.keys(statBlocks).map(function (key) {
        var c = __assign(__assign({}, StatBlock_1.StatBlock.Default()), statBlocks[key]);
        return {
            Name: c.Name,
            Id: c.Id,
            Path: c.Path,
            SearchHint: StatBlock_1.StatBlock.GetSearchHint(c),
            FilterDimensions: StatBlock_1.StatBlock.FilterDimensions(c),
            Version: c.Version,
            Link: "/my/statblocks/".concat(c.Id),
            LastUpdateMs: c.LastUpdateMs || 0
        };
    });
}
function getSpellListings(spells) {
    return Object.keys(spells).map(function (key) {
        var c = __assign(__assign({}, Spell_1.Spell.Default()), spells[key]);
        return {
            Name: c.Name,
            Id: c.Id,
            Path: c.Path,
            SearchHint: Spell_1.Spell.GetSearchHint(c),
            FilterDimensions: Spell_1.Spell.GetFilterDimensions(c),
            Version: c.Version,
            Link: "/my/spells/".concat(c.Id),
            LastUpdateMs: c.LastUpdateMs || 0
        };
    });
}
function getEncounterListings(encounters) {
    return Object.keys(encounters).map(function (key) {
        var c = __assign(__assign({}, SavedEncounter_1.SavedEncounter.Default()), encounters[key]);
        return {
            Name: c.Name,
            Id: c.Id,
            Path: c.Path,
            SearchHint: SavedEncounter_1.SavedEncounter.GetSearchHint(c),
            FilterDimensions: {},
            Version: c.Version,
            Link: "/my/encounters/".concat(c.Id),
            LastUpdateMs: c.LastUpdateMs || 0
        };
    });
}
function getPersistentCharacterListings(persistentCharacters) {
    return Object.keys(persistentCharacters).map(function (key) {
        var c = __assign(__assign({}, PersistentCharacter_1.PersistentCharacter.Default()), persistentCharacters[key]);
        return {
            Name: c.Name,
            Id: c.Id,
            Path: c.Path,
            SearchHint: PersistentCharacter_1.PersistentCharacter.GetSearchHint(c),
            FilterDimensions: PersistentCharacter_1.PersistentCharacter.GetFilterDimensions(c),
            Version: c.Version,
            Link: "/my/persistentcharacters/".concat(c.Id),
            LastUpdateMs: c.LastUpdateMs || 0
        };
    });
}
function setSettings(userId, settings) {
    return __awaiter(this, void 0, void 0, function () {
        var db, users, result;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!mongoClient) {
                        console.error("No mongo client initialized");
                        throw "No mongo client initialized";
                    }
                    if (typeof userId === "string") {
                        userId = new mongo.ObjectId(userId);
                    }
                    db = mongoClient.db();
                    users = db.collection("users");
                    return [4, users.updateOne({ _id: userId }, { $set: { settings: settings } })];
                case 1:
                    result = _a.sent();
                    return [2, result.modifiedCount];
            }
        });
    });
}
exports.setSettings = setSettings;
function getEntity(entityPath, userId, entityId) {
    return __awaiter(this, void 0, void 0, function () {
        var db, user, entities;
        var _a;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    if (!mongoClient) {
                        console.error("No mongo client initialized");
                        throw "No mongo client initialized";
                    }
                    db = mongoClient.db();
                    if (typeof userId === "string") {
                        userId = new mongo.ObjectId(userId);
                    }
                    return [4, db.collection("users").findOne({ _id: userId }, {
                            projection: (_a = {},
                                _a["".concat(entityPath, ".").concat(entityId)] = true,
                                _a)
                        })];
                case 1:
                    user = _b.sent();
                    if (!user) {
                        return [2, null];
                    }
                    entities = user[entityPath];
                    if (entities === undefined) {
                        return [2, null];
                    }
                    return [2, entities[entityId]];
            }
        });
    });
}
exports.getEntity = getEntity;
function deleteEntity(entityPath, userId, entityId, callBack) {
    return __awaiter(this, void 0, void 0, function () {
        var db, users, result;
        var _a;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    if (!mongoClient) {
                        console.error("No mongo client initialized");
                        throw "No mongo client initialized";
                    }
                    db = mongoClient.db();
                    users = db.collection("users");
                    if (typeof userId === "string") {
                        userId = new mongo.ObjectId(userId);
                    }
                    return [4, users.updateOne({ _id: userId }, {
                            $unset: (_a = {},
                                _a["".concat(entityPath, ".").concat(entityId)] = "",
                                _a)
                        })];
                case 1:
                    result = _b.sent();
                    callBack(result.modifiedCount);
                    return [2];
            }
        });
    });
}
exports.deleteEntity = deleteEntity;
function saveEntity(entityPath, userId, entity) {
    return __awaiter(this, void 0, void 0, function () {
        var db, result;
        var _a;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    if (!mongoClient) {
                        console.error("No mongo client initialized");
                        throw "No mongo client initialized";
                    }
                    if (!entity.Id || !entity.Version) {
                        throw "Entity missing Id or Version";
                    }
                    if (entity.Id.indexOf(".") > -1) {
                        throw "Entity Id cannot contain .";
                    }
                    db = mongoClient.db();
                    if (typeof userId === "string") {
                        userId = new mongo.ObjectId(userId);
                    }
                    return [4, db.collection("users").updateOne({ _id: userId }, {
                            $set: (_a = {},
                                _a["".concat(entityPath, ".").concat(entity.Id)] = entity,
                                _a)
                        })];
                case 1:
                    result = _b.sent();
                    return [2, result.modifiedCount];
            }
        });
    });
}
exports.saveEntity = saveEntity;
function saveEntitySet(entityPath, userId, entities) {
    return __awaiter(this, void 0, void 0, function () {
        var _i, entities_1, entity, db, users, user, updatedEntities, _a, entities_2, entity, result;
        var _b;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    if (!mongoClient) {
                        console.error("No mongo client initialized");
                        throw "No mongo client initialized";
                    }
                    for (_i = 0, entities_1 = entities; _i < entities_1.length; _i++) {
                        entity = entities_1[_i];
                        if (!entity.Id || !entity.Version) {
                            throw "Entity missing Id or Version";
                        }
                    }
                    db = mongoClient.db();
                    users = db.collection("users");
                    if (typeof userId === "string") {
                        userId = new mongo.ObjectId(userId);
                    }
                    return [4, users.findOne({ _id: userId })];
                case 1:
                    user = _c.sent();
                    if (user == null) {
                        return [2, null];
                    }
                    updatedEntities = user[entityPath] || {};
                    for (_a = 0, entities_2 = entities; _a < entities_2.length; _a++) {
                        entity = entities_2[_a];
                        updatedEntities[entity.Id] = entity;
                    }
                    return [4, users.updateOne({ _id: userId }, {
                            $set: (_b = {},
                                _b["".concat(entityPath)] = updatedEntities,
                                _b)
                        })];
                case 2:
                    result = _c.sent();
                    if (!result) {
                        return [2, 0];
                    }
                    return [2, result.matchedCount];
            }
        });
    });
}
exports.saveEntitySet = saveEntitySet;
//# sourceMappingURL=dbconnection.js.map