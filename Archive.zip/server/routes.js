"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var bodyParser = require("body-parser");
var express = require("express");
var moment = require("moment");
var mustacheExpress = require("mustache-express");
var url_1 = require("url");
var Toolbox_1 = require("../common/Toolbox");
var configureBasicRulesContent_1 = require("./configureBasicRulesContent");
var dbconnection_1 = require("./dbconnection");
var metrics_1 = require("./metrics");
var patreon_1 = require("./patreon");
var storageroutes_1 = require("./storageroutes");
var user_1 = require("./user");
var configureOpen5eContent_1 = require("./configureOpen5eContent");
var baseUrl = process.env.BASE_URL || "";
var patreonClientId = process.env.PATREON_CLIENT_ID || "PATREON_CLIENT_ID";
var defaultAccountLevel = process.env.DEFAULT_ACCOUNT_LEVEL || "free";
var googleAnalyticsId = process.env.GOOGLE_ANALYTICS_ID || "";
var twitterPixelId = process.env.TWITTER_PIXEL_ID || "";
var appVersion = require("../package.json").version;
var getClientOptions = function (session) {
    var encounterId = session.encounterId || (0, Toolbox_1.probablyUniqueString)();
    var patreonLoginUrl = "http://www.patreon.com/oauth2/authorize" +
        "?response_type=code&client_id=".concat(patreonClientId) +
        "&redirect_uri=".concat(baseUrl, "/r/patreon") +
        "&scope=" +
        encodeURIComponent("identity identity.memberships identity[email]") +
        "&state=".concat(encounterId);
    var environment = {
        EncounterId: encounterId,
        BaseUrl: baseUrl,
        PatreonLoginUrl: patreonLoginUrl,
        IsLoggedIn: session.isLoggedIn || false,
        HasStorage: session.hasStorage || false,
        HasEpicInitiative: session.hasEpicInitiative || false,
        SendMetrics: process.env.METRICS_DB_CONNECTION_STRING != undefined,
        PostedEncounter: null,
        SentryDSN: process.env.SENTRY_DSN || null
    };
    if (session.postedEncounter) {
        environment.PostedEncounter = session.postedEncounter;
        delete session.postedEncounter;
    }
    return {
        environmentJSON: JSON.stringify(environment),
        baseUrl: baseUrl,
        appVersion: appVersion,
        googleAnalyticsId: googleAnalyticsId,
        twitterPixelId: twitterPixelId,
        accountLevel: getAccountLevel(session)
    };
};
function getAccountLevel(session) {
    if (!session.isLoggedIn) {
        return "LoggedOut";
    }
    if (!session.hasStorage) {
        return "LoggedInFree";
    }
    if (!session.hasEpicInitiative) {
        return "AccountSync";
    }
    return "EpicInitiative";
}
function default_1(app, playerViews) {
    var _this = this;
    var mustacheEngine = mustacheExpress();
    var cacheMaxAge = moment.duration(7, "days").asMilliseconds();
    if (process.env.NODE_ENV === "development") {
        mustacheEngine.cache._max = 0;
        cacheMaxAge = 0;
    }
    app.engine("html", mustacheEngine);
    app.set("view engine", "html");
    app.set("views", __dirname + "/../html");
    app.use(express.static(__dirname + "/../public", { maxAge: cacheMaxAge }));
    app.use(bodyParser.json({
        verify: function (req, res, buf, encoding) {
            req["rawBody"] = buf.toString();
        }
    }));
    app.use(bodyParser.urlencoded({ extended: false }));
    (0, metrics_1.configureMetricsRoutes)(app);
    app.get("/", function (req, res) { return __awaiter(_this, void 0, void 0, function () {
        var session, _a, renderOptions;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    session = req.session;
                    if (session === undefined) {
                        throw "Session is not available";
                    }
                    _a = session;
                    return [4, playerViews.InitializeNew()];
                case 1:
                    _a.encounterId = _b.sent();
                    renderOptions = getClientOptions(session);
                    return [2, res.render("landing", renderOptions)];
            }
        });
    }); });
    app.get("/e/:id", function (req, res) {
        var session = req.session;
        if (session === undefined) {
            throw "Session is not available";
        }
        session.encounterId = req.params.id;
        var urlObject = new url_1.URL(req.url, baseUrl);
        var queryString = urlObject.search;
        res.redirect("/e/" + queryString);
    });
    app.get("/e/", function (req, res) { return __awaiter(_this, void 0, void 0, function () {
        var session, options;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    session = req.session;
                    if (session === undefined) {
                        throw "Session is not available";
                    }
                    if (!(defaultAccountLevel !== "free")) return [3, 2];
                    return [4, setupLocalDefaultUser(session)];
                case 1:
                    _a.sent();
                    _a.label = 2;
                case 2:
                    updateSession(session);
                    options = getClientOptions(session);
                    return [2, res.render("tracker", options)];
            }
        });
    }); });
    app.get("/p/:id", function (req, res) {
        var session = req.session;
        if (session == null) {
            throw "Session is not available";
        }
        session.encounterId = req.params.id;
        res.render("playerview", getClientOptions(session));
    });
    app.get("/playerviews/:id", function (req, res) { return __awaiter(_this, void 0, void 0, function () {
        var playerView;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4, playerViews.Get(req.params.id)];
                case 1:
                    playerView = _a.sent();
                    res.json(playerView);
                    return [2];
            }
        });
    }); });
    app.get("/states/:name", function (req, res) { return __awaiter(_this, void 0, void 0, function () {
        var playerView;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4, playerViews.Get(req.params.id)];
                case 1:
                    playerView = _a.sent();
                    res.json(playerView);
                    return [2];
            }
        });
    }); });
    (0, configureBasicRulesContent_1.configureBasicRulesContent)(app);
    (0, configureOpen5eContent_1.configureOpen5eContent)(app);
    var importEncounter = function (req, res) { return __awaiter(_this, void 0, void 0, function () {
        var newViewId, session;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4, playerViews.InitializeNew()];
                case 1:
                    newViewId = _a.sent();
                    session = req.session;
                    if (typeof req.body.Combatants === "string") {
                        session.postedEncounter = {
                            Combatants: (0, Toolbox_1.ParseJSONOrDefault)(req.body.Combatants, [])
                        };
                    }
                    else {
                        session.postedEncounter = req.body;
                    }
                    res.redirect("/e/" + newViewId);
                    return [2];
            }
        });
    }); };
    app.post("/launchencounter/", importEncounter);
    app.post("/importencounter/", importEncounter);
    app.get("/transferlocalstorage/", function (req, res) {
        res.render("transferlocalstorage", { baseUrl: baseUrl });
    });
    (0, patreon_1.configureLoginRedirect)(app);
    (0, patreon_1.configureLogout)(app);
    (0, patreon_1.configurePatreonWebhookReceiver)(app);
    (0, storageroutes_1.default)(app);
    (0, patreon_1.startNewsUpdates)(app);
}
exports.default = default_1;
function setupLocalDefaultUser(session) {
    return __awaiter(this, void 0, void 0, function () {
        var accountStatus, user;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    accountStatus = user_1.AccountStatus.None;
                    if (defaultAccountLevel === "accountsync") {
                        session.hasStorage = true;
                        accountStatus = user_1.AccountStatus.Pledge;
                    }
                    if (defaultAccountLevel === "epicinitiative") {
                        session.hasStorage = true;
                        session.hasEpicInitiative = true;
                        accountStatus = user_1.AccountStatus.Epic;
                    }
                    session.isLoggedIn = true;
                    return [4, (0, dbconnection_1.upsertUser)(process.env.DEFAULT_PATREON_ID || "defaultPatreonId", accountStatus, "")];
                case 1:
                    user = _a.sent();
                    if (user) {
                        session.userId = user._id;
                    }
                    return [2];
            }
        });
    });
}
function updateSession(session) {
    return __awaiter(this, void 0, void 0, function () {
        var account;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!session.userId) return [3, 2];
                    return [4, (0, dbconnection_1.getAccount)(session.userId)];
                case 1:
                    account = _a.sent();
                    if (account) {
                        (0, patreon_1.updateSessionAccountFeatures)(session, account.accountStatus);
                    }
                    _a.label = 2;
                case 2: return [2];
            }
        });
    });
}
//# sourceMappingURL=routes.js.map