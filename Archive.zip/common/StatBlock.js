"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatBlock = void 0;
var _ = require("lodash");
var Toolbox_1 = require("./Toolbox");
var StatBlock;
(function (StatBlock) {
    StatBlock.AbilityNames = ["Str", "Dex", "Con", "Int", "Wis", "Cha"];
    var BaseTypes = [
        "aberration",
        "beast",
        "celestial",
        "construct",
        "dragon",
        "elemental",
        "fey",
        "fiend",
        "giant",
        "humanoid",
        "monstrosity",
        "ooze",
        "plant",
        "undead"
    ];
    StatBlock.GetSearchHint = function (statBlock) {
        return statBlock.Type.toLocaleLowerCase().replace(/[^\w\s]/g, "");
    };
    StatBlock.FilterDimensions = function (statBlock) {
        var baseType = _.find(BaseTypes, function (t) { return statBlock.Type.search(t) != -1; });
        return {
            Level: statBlock.Challenge,
            Source: statBlock.Source,
            Type: _.startCase(baseType)
        };
    };
    StatBlock.IsPlayerCharacter = function (statBlock) {
        return statBlock.Player.length > 0;
    };
    StatBlock.Default = function () { return ({
        Id: (0, Toolbox_1.probablyUniqueString)(),
        Name: "",
        Path: "",
        Source: "",
        Type: "",
        HP: { Value: 1, Notes: "(1d1+0)" },
        AC: { Value: 10, Notes: "" },
        InitiativeModifier: 0,
        InitiativeAdvantage: false,
        Speed: [],
        Abilities: { Str: 10, Dex: 10, Con: 10, Int: 10, Wis: 10, Cha: 10 },
        DamageVulnerabilities: [],
        DamageResistances: [],
        DamageImmunities: [],
        ConditionImmunities: [],
        Saves: [],
        Skills: [],
        Senses: [],
        Languages: [],
        Challenge: "",
        Traits: [],
        Actions: [],
        BonusActions: [],
        Reactions: [],
        LegendaryActions: [],
        MythicActions: [],
        Description: "",
        Player: "",
        Version: process.env.VERSION || "0.0.0",
        ImageURL: ""
    }); };
})(StatBlock || (exports.StatBlock = StatBlock = {}));
//# sourceMappingURL=StatBlock.js.map