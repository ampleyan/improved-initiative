## TERMS OF SERVICE

Improved Initiative is for entertainment purposes only, and is not responsible for dead player characters or other combat mishaps that may occur during its use. Improved Initiative is offered with no warranty of any kind. Improved Initiative is not responsible or liable for the deletion of any user data used by or maintained by the app. You are responsible for backing up any data that you use with the app.

## PRIVACY POLICY

In order to provide the web app, Improved Initiative collects some information from users, and it uses cookies. If you don't log in, the app collects your IP address and session identifier. If you log in with Patreon, the app collects your email address, and a unique identifier associated with your Patreon account as a key for your app data.

In order to improve the app's user experience, the app can collect data about how it is being used. If you opt in, your usage patterns will be tracked and stored by the app. This helps determine what features should be built next.

None of your personal information is ever sold to a third party. All of the app's behaviors are documented in the source code on [GitHub](https://github.com/cynicaloptimist/improved-initiative). In the case of any contradictions between this document and the source code, the source code takes precedence.
