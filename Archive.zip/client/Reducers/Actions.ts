import { CombatantAction } from "./CombatantActions";
import { EncounterAction } from "./EncounterActions";

export type Action = EncounterAction | CombatantAction;
