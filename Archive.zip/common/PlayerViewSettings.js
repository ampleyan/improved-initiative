"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HpVerbosityOption = void 0;
var HpVerbosityOption;
(function (HpVerbosityOption) {
    HpVerbosityOption["ActualHP"] = "Actual HP";
    HpVerbosityOption["ColoredLabel"] = "Colored Label";
    HpVerbosityOption["MonochromeLabel"] = "Monochrome Label";
    HpVerbosityOption["DamageTaken"] = "Damage Taken";
    HpVerbosityOption["HideAll"] = "Hide All";
})(HpVerbosityOption || (exports.HpVerbosityOption = HpVerbosityOption = {}));
//# sourceMappingURL=PlayerViewSettings.js.map