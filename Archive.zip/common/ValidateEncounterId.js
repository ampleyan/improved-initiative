"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ValidateEncounterId = void 0;
var validIdRegex = new RegExp(/^[\w\d]{4,20}$/);
function ValidateEncounterId(id) {
    return validIdRegex.test(id);
}
exports.ValidateEncounterId = ValidateEncounterId;
//# sourceMappingURL=ValidateEncounterId.js.map