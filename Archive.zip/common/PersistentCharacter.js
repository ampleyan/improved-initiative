"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PersistentCharacter = void 0;
var moment_1 = require("moment");
var StatBlock_1 = require("./StatBlock");
var Toolbox_1 = require("./Toolbox");
var PersistentCharacter;
(function (PersistentCharacter) {
    function Initialize(statBlock) {
        return {
            Id: statBlock.Id || (0, Toolbox_1.probablyUniqueString)(),
            Version: statBlock.Version,
            Name: statBlock.Name,
            Path: statBlock.Path,
            LastUpdateMs: (0, moment_1.now)(),
            CurrentHP: statBlock.HP.Value,
            StatBlock: statBlock,
            Notes: ""
        };
    }
    PersistentCharacter.Initialize = Initialize;
    PersistentCharacter.Default = function () { return Initialize(StatBlock_1.StatBlock.Default()); };
    PersistentCharacter.GetSearchHint = function (character) {
        return character.StatBlock.Type;
    };
    var GetTotalLevelFromString = function (levelString) {
        var matches = levelString.toString().match(/\d+/g);
        if (!matches) {
            return "";
        }
        return matches
            .reduce(function (total, digitMatch) {
            var level = parseInt(digitMatch);
            if (!isNaN(level)) {
                return total + level;
            }
            return total;
        }, 0)
            .toString();
    };
    PersistentCharacter.GetFilterDimensions = function (character) { return ({
        Level: GetTotalLevelFromString(character.StatBlock.Challenge)
    }); };
})(PersistentCharacter || (exports.PersistentCharacter = PersistentCharacter = {}));
//# sourceMappingURL=PersistentCharacter.js.map