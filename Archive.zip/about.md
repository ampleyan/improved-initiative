# About Improved Initiative

**Improved Initiative** was created by [Evan Bailey](mailto:improvedinitiativedev@gmail.com). All Wizards of the Coast content provided under terms of the [Open Gaming License Version 1.0a](http://media.wizards.com/2016/downloads/SRD-OGL_V1.1.pdf).
