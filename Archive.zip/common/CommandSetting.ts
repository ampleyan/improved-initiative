export class CommandSetting {
  public Name: string;
  public KeyBinding: string;
  public ShowOnActionBar: boolean;
  public ShowInCombatantRow: boolean;
}
