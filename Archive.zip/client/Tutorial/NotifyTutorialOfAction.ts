import * as ko from "knockout";

export const NotifyTutorialOfAction = ko.observable<string>(null);
