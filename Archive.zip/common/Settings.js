"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDefaultSettings = exports.PostCombatStatsOption = exports.AutoRerollInitiativeOption = exports.AutoGroupInitiativeOption = void 0;
var PlayerViewSettings_1 = require("./PlayerViewSettings");
var AutoGroupInitiativeOption;
(function (AutoGroupInitiativeOption) {
    AutoGroupInitiativeOption["None"] = "None";
    AutoGroupInitiativeOption["ByName"] = "By Name";
    AutoGroupInitiativeOption["SideInitiative"] = "Side Initiative";
})(AutoGroupInitiativeOption || (exports.AutoGroupInitiativeOption = AutoGroupInitiativeOption = {}));
var AutoRerollInitiativeOption;
(function (AutoRerollInitiativeOption) {
    AutoRerollInitiativeOption["No"] = "No";
    AutoRerollInitiativeOption["Prompt"] = "Prompt";
    AutoRerollInitiativeOption["Automatic"] = "Automatic";
})(AutoRerollInitiativeOption || (exports.AutoRerollInitiativeOption = AutoRerollInitiativeOption = {}));
var PostCombatStatsOption;
(function (PostCombatStatsOption) {
    PostCombatStatsOption["None"] = "None";
    PostCombatStatsOption["EncounterViewOnly"] = "Encounter view only";
    PostCombatStatsOption["PlayerViewOnly"] = "Player view only";
    PostCombatStatsOption["Both"] = "Both";
})(PostCombatStatsOption || (exports.PostCombatStatsOption = PostCombatStatsOption = {}));
function getDefaultSettings() {
    return {
        Commands: [],
        Rules: {
            RollMonsterHp: false,
            EnableBossAndMinionHP: false,
            AllowNegativeHP: false,
            AutoCheckConcentration: true,
            AutoGroupInitiative: AutoGroupInitiativeOption.None,
            AutoRerollInitiative: AutoRerollInitiativeOption.No
        },
        TrackerView: {
            DisplayPortraits: false,
            DisplayRoundCounter: false,
            DisplayTurnTimer: false,
            DisplayDifficulty: true,
            DisplayHPBar: false,
            DisplayCombatantColor: false,
            DisplayReactionTracker: false,
            PostCombatStats: PostCombatStatsOption.None
        },
        PlayerView: {
            ActiveCombatantOnTop: false,
            AllowPlayerSuggestions: false,
            AllowTagSuggestions: false,
            MonsterHPVerbosity: PlayerViewSettings_1.HpVerbosityOption.ColoredLabel,
            PlayerHPVerbosity: PlayerViewSettings_1.HpVerbosityOption.ActualHP,
            HideMonstersOutsideEncounter: false,
            DisplayRoundCounter: false,
            DisplayTurnTimer: false,
            DisplayPortraits: false,
            DisplayCombatantColor: false,
            SplashPortraits: false,
            CustomCSS: "",
            CustomStyles: {
                combatantBackground: "",
                combatantText: "",
                activeCombatantIndicator: "",
                font: "",
                headerBackground: "",
                headerText: "",
                mainBackground: "",
                backgroundUrl: ""
            },
            CustomEncounterId: ""
        },
        PreloadedContent: {
            BasicRules: true,
            Open5eContent: true
        },
        RecentItemIds: [],
        Version: process.env.VERSION || "0.0.0"
    };
}
exports.getDefaultSettings = getDefaultSettings;
//# sourceMappingURL=Settings.js.map