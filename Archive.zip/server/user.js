"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AccountStatus = void 0;
var AccountStatus;
(function (AccountStatus) {
    AccountStatus["None"] = "none";
    AccountStatus["Pledge"] = "pledge";
    AccountStatus["Epic"] = "epic";
})(AccountStatus || (exports.AccountStatus = AccountStatus = {}));
//# sourceMappingURL=user.js.map