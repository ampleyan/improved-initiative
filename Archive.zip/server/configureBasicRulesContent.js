"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.configureBasicRulesContent = void 0;
var Spell_1 = require("../common/Spell");
var StatBlock_1 = require("../common/StatBlock");
var library_1 = require("./library");
function configureBasicRulesContent(app) {
    var statBlockLibrary = library_1.Library.FromFile("ogl_creatures.json", "/statblocks/", StatBlock_1.StatBlock.GetSearchHint, StatBlock_1.StatBlock.FilterDimensions);
    app.get(statBlockLibrary.Route(), function (req, res) {
        res.json(statBlockLibrary.GetListings());
    });
    app.get(statBlockLibrary.Route() + ":id", function (req, res) {
        res.json(statBlockLibrary.GetById(req.params.id));
    });
    var spellLibrary = library_1.Library.FromFile("ogl_spells.json", "/spells/", Spell_1.Spell.GetSearchHint, Spell_1.Spell.GetFilterDimensions);
    app.get(spellLibrary.Route(), function (req, res) {
        res.json(spellLibrary.GetListings());
    });
    app.get(spellLibrary.Route() + ":id", function (req, res) {
        res.json(spellLibrary.GetById(req.params.id));
    });
}
exports.configureBasicRulesContent = configureBasicRulesContent;
//# sourceMappingURL=configureBasicRulesContent.js.map