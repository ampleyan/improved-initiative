"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizeChallengeRating = exports.ParseJSONOrDefault = exports.concatenatedStringRegex = exports.probablyUniqueString = exports.toModifierString = void 0;
var lodash_1 = require("lodash");
function toModifierString(number) {
    if (number >= 0) {
        return "+".concat(number);
    }
    return number.toString();
}
exports.toModifierString = toModifierString;
function probablyUniqueString() {
    var chars = "1234567890abcdefghijkmnpqrstuvxyz";
    var probablyUniqueString = "";
    for (var i = 0; i < 8; i++) {
        var index = Math.floor(Math.random() * chars.length);
        probablyUniqueString += chars[index];
    }
    return probablyUniqueString;
}
exports.probablyUniqueString = probablyUniqueString;
function concatenatedStringRegex(strings) {
    var allStrings = strings
        .map(function (s) { return (0, lodash_1.escapeRegExp)(s); })
        .sort(function (a, b) { return b.localeCompare(a); });
    if (allStrings.length === 0) {
        return new RegExp("a^");
    }
    return new RegExp("\\b(".concat(allStrings.join("|"), ")\\b"), "gim");
}
exports.concatenatedStringRegex = concatenatedStringRegex;
function ParseJSONOrDefault(json, defaultValue) {
    try {
        return JSON.parse(json);
    }
    catch (_a) {
        return defaultValue;
    }
}
exports.ParseJSONOrDefault = ParseJSONOrDefault;
function normalizeChallengeRating(challengeRating) {
    if (challengeRating == "0.125") {
        return "1/8";
    }
    if (challengeRating == "0.25") {
        return "1/4";
    }
    if (challengeRating == "0.5") {
        return "1/2";
    }
    return challengeRating;
}
exports.normalizeChallengeRating = normalizeChallengeRating;
//# sourceMappingURL=Toolbox.js.map