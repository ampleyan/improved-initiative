"use strict";
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Spell = void 0;
var Toolbox_1 = require("./Toolbox");
var Spell;
(function (Spell) {
    Spell.GetSearchHint = function (spell) {
        return __spreadArray([spell.Name, spell.School], spell.Classes, true).join(" ");
    };
    Spell.GetFilterDimensions = function (spell) { return ({
        Level: spell.Level.toString(),
        Type: spell.School
    }); };
    Spell.Default = function () {
        return {
            Id: (0, Toolbox_1.probablyUniqueString)(),
            Version: process.env.VERSION || "0.0.0",
            Name: "",
            Path: "",
            Source: "",
            CastingTime: "",
            Classes: [],
            Components: "",
            Description: "",
            Duration: "",
            Level: 0,
            Range: "",
            Ritual: false,
            School: ""
        };
    };
})(Spell || (exports.Spell = Spell = {}));
//# sourceMappingURL=Spell.js.map