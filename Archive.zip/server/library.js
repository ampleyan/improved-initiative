"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Library = void 0;
var fs = require("fs");
var path = require("path");
var sourceAbbreviations = {
    "monster-manual": "mm",
    "basic-rules": "mm",
    "players-handbook": "phb"
};
var formatStringForId = function (str) {
    return str
        .toLocaleLowerCase()
        .replace(/[\s]/g, "-")
        .replace(/[^a-z0-9-]/g, "");
};
var createId = function (name, source) {
    var sourceString = formatStringForId(source);
    var sourcePrefix = sourceAbbreviations[sourceString] || sourceString;
    var lowerCaseName = formatStringForId(name);
    return "".concat(sourcePrefix, ".").concat(lowerCaseName);
};
var Library = (function () {
    function Library(route, getSearchHint, getFilterDimensions) {
        var _this = this;
        this.route = route;
        this.getSearchHint = getSearchHint;
        this.getFilterDimensions = getFilterDimensions;
        this.items = {};
        this.listings = [];
        this.Route = function () { return _this.route; };
    }
    Library.FromFile = function (filename, route, getSearchHint, getMetadata) {
        var library = new Library(route, getSearchHint, getMetadata);
        var filePath = path.join(__dirname, "..", filename);
        fs.readFile(filePath, function (err, buffer) {
            if (err) {
                throw "Couldn't read ".concat(filePath, " as a library: ").concat(err);
            }
            var newItems = JSON.parse(buffer.toString());
            library.Add(newItems);
        });
        return library;
    };
    Library.prototype.Add = function (items) {
        var _this = this;
        items.forEach(function (c) {
            if (!(c.Name && c.Source)) {
                throw "Missing Name or Source: Couldn't import ".concat(JSON.stringify(c));
            }
            c.Id = createId(c.Name, c.Source);
            _this.items[c.Id] = c;
            var listing = {
                Name: c.Name,
                Id: c.Id,
                Path: c.Path || "",
                SearchHint: _this.getSearchHint(c),
                FilterDimensions: _this.getFilterDimensions(c),
                Link: _this.route + c.Id,
                LastUpdateMs: 0
            };
            _this.listings.push(listing);
        });
    };
    Library.prototype.GetById = function (id) {
        return this.items[id];
    };
    Library.prototype.GetListings = function () {
        return this.listings;
    };
    return Library;
}());
exports.Library = Library;
//# sourceMappingURL=library.js.map